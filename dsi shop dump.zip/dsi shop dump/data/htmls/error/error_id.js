//----------------------------------------
//-- define : message id num.

var JMS_shop_error_title = 0;
var JMS_shop_error_code  = 1;
var JMS_shop_menu        = 2;
var JMS_shop_reset       = 3;
var JMS_shop_ok          = 4;
var JMS_shop_title       = 5;
var JMS_shop_menu_02     = 6;
var JMS_shop_reset_02    = 7;
var JMS_shop_yes         = 8;
var JMS_shop_no          = 9;