//----------------------------------------
//-- define : SE No. (refer to sound_data.sadl)

/* #### 20080726 #### Changed SE No. */
/* #### 20080911 #### Changed SE No. */

var TWL_SHOP_SE_ONMOUSEDOWN   =  16; // #define TWL_CMN_SE_TOUCH        16 // 16 // 20
var TWL_SHOP_SE_ONCLICK       =  17; // #define TWL_CMN_SE_DECIDE       17 // 17 // 19
var TWL_SHOP_SE_TRANSIT       =  37; // #define TWL_SHP_SE_LOADED       37 // 35 // 17
var TWL_SHOP_SE_INVALID       =  23; // #define TWL_CMN_SE_INVALID      23 // 23 // NEW
var TWL_SHOP_SE_WARNING       =  36; // #define TWL_SHP_SE_WARNING_PAGE 36 // 34 // NEW
